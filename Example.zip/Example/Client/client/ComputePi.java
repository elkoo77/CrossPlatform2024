package client;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.math.BigDecimal;
import compute.Compute;

public class ComputePi {
    public static void main(String[] args) {

        System.setProperty("java.security.policy", "program.policy");

        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }
        try {
            String host = args[0];
            int precision = Integer.parseInt(args[1]);

            Registry registry = LocateRegistry.getRegistry(host);
            String name = "Compute";
            Compute comp = (Compute) registry.lookup(name);
            Pi task = new Pi(precision);
            BigDecimal pi = comp.executeTask(task);
            System.out.println("Computed Pi: " + pi);
        } catch (Exception e) {
            System.err.println("ComputePi exception:");
            e.printStackTrace();
        }
    }
}
